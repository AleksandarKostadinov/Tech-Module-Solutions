﻿namespace _05.ClosestTwoPoints
{
    public class Point
    {
        public int X { get; set; }
        public int Y { get; set; }
    }
}
