﻿namespace _07.AndreyAndBilliard
{
    using System.Collections.Generic;

    class Customer
    {
        public string Name { get; set; }
        public Dictionary<string, double> Order { get; set; }
        public double Bill { get; set; }
    }
}
