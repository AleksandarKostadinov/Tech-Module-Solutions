﻿namespace _05.BookLibrary
{
    using System.Collections.Generic;

    class Library
    {
        public string Name { get; set; }
        public List<Book> Books { get; set; }
    }
}
