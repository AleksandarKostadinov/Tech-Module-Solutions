﻿namespace _06.BookLibraryModification
{
    using System.Collections.Generic;

    class Library
    {
        public string Name { get; set; }
        public List<Book> Books { get; set; }
    }
}
