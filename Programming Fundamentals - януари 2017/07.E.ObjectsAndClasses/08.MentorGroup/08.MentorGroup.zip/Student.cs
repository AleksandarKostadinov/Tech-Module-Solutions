﻿namespace _08.MentorGroup
{
    using System;
    using System.Collections.Generic;

    class Student
    {
        public List<string> comments { get; set; }
        public List<DateTime> datesAttended { get; set; }
    }
}
